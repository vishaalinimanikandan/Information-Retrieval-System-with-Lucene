    1  sudo apt update && sudo apt upgrade -y
    2  sudo apt install default-jdk -y
    3  java -version
    4  sudo apt install maven -y
    5  mvn -version
    6  cd /home/azureuser
    7  ls
    8  pwd
   10  cd LuceneProject
   11  nano pom.xml
   12  mvn compile
   13  nano pom.xml
   14  mvn compile
   15  nano pom.xml
   16  mvn compile
   17  mkdir -p src/main/java/com/example
   18  nano src/main/java/com/example/CranfieldIndexer.java
   19  ls
   20  pwd
   21  nano src/main/java/com/example/CranfieldIndexer.java
   22  mvn compile
   23  mvn exec:java -Dexec.mainClass="com.example.CranfieldIndexer"
   24  ls cranfield_index
   25  ls -la cranfield_index
   26  mvn exec:java -Dexec.mainClass="com.example.CranfieldIndexer"
   27  nano src/main/java/com/example/CranfieldIndexer.java
   28  mvn exec:java -Dexec.mainClass="com.example.CranfieldIndexer"
   29  PWD
   30  pwd
   31  ls
   32  cd cranfield_data
   33  ls
   34  cd cran
   35  ls
   36  pwd
   37  nano src/main/java/com/example/CranfieldIndexer.java
   38  ls
   39  cd ..
   40  nano src/main/java/com/example/CranfieldIndexer.java
   41  pwd
   42  cd LuceneProject
   43  nano src/main/java/com/example/CranfieldIndexer.java
   44  mvn exec:java -Dexec.mainClass="com.example.CranfieldIndexer"
   45  sudo apt install tree -y
   46  tree
   47  nano src/main/java/com/example/CranfieldIndexer.java
   48  mvn compile
   49  mvn exec:java -Dexec.mainClass="com.example.CranfieldIndexer"
   50  ls -la cranfield_index
   51  nano src/main/java/com/example/CranfieldQuery.java
   52  mvn compile
   53  mvn exec:java -Dexec.mainClass="com.example.CranfieldQuery"
   54  nano src/main/java/com/example/CranfieldQuery.java
   55  mvn compile
   56  nano src/main/java/com/example/CranfieldQuery.java
   57  mvn exec:java -Dexec.mainClass="com.example.CranfieldQuery"
   58  nano src/main/java/com/example/CranfieldIndexer.java
   59  nano src/main/java/com/example/CranfieldQuery.java
   60  nano src/main/java/com/example/CranfieldIndexer.java
   61  nano src/main/java/com/example/CranfieldBM25Query.java
   62  mvn compile
   63  mvn exec:java -Dexec.mainClass="com.example.CranfieldBM25Query"
   64  nano src/main/java/com/example/CranfieldBM25Query.java
   65  mvn compile
   66  nano src/main/java/com/example/CranfieldBM25Query.java
   67  mvn compile
   68  nano src/main/java/com/example/CranfieldBM25Query.java
   69  mvn compile
   70  mvn exec:java -Dexec.mainClass="com.example.CranfieldBM25Query"
   71  nano src/main/java/com/example/CranfieldQuery.java
   72  mvn compile
   73  mv src/main/java/com/example/CranfieldQuery.java src/main/java/com/example/CranfieldVSMQuery.java
   74  mvn compile
   75  mvn exec:java -Dexec.mainClass="com.example.CranfieldVSMQuery"
   76  wget https://trec.nist.gov/trec_eval/trec_eval_latest.tar.gz
   77  tar -xzf trec_eval_latest.tar.gz
   78  cd trec_eval
   79  ls
   80  cd trec_eval-9.0.7
   81  make
   82  nano vsm_results.txt
   83  ./trec_eval /path/to/cranqrel /path/to/bm25_results.txt
   84  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
   85  ./trec_eval-9.0.7 /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
   86  ls -la
   87  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
   88  cd ..
   89  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
   90  cd trec_eval-9.0.7

  116  cd trec_eval-9.0.7
  117  make
  118  sudo apt install make
  119  make
  120  cd ..
  121  sudo apt install build-essential -y
  122  cd /home/azureuser/LuceneProject/trec_eval-9.0.7
  123  make
  124  cd trec_eval-9.0.7
  125  make
  126  ls -la
  127  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  128  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  129  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  130  nano /home/azureuser/LuceneProject/bm25_results.txt
  131  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  132  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  133  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  134  cat -A /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel | head -n 10
  135  sed -i 's/\r//' /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  136  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  137  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  138  wget http://ir.dcs.gla.ac.uk/resources/test_collections/cran/cranqrel -O /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  139  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  140  cd ..
  141  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  142  cd trec_eval-9.0.7
  143  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt

  149  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  150  cd ..
  151  ls
  152  cd cranfield_data/cran
  153  ls
  154  nano cranqrel
  155  du -h /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  156  cd ..
  157  ls
  158  cd cranfield_data1
  159  ls
  160  cd cran
  161  ls
  162  du -h /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  163  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  164  cd ..
  165  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  166  wget http://ir.dcs.gla.ac.uk/resources/test_collections/cran/cranqrel -O /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel

  171  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  172  cd trec_eval-9.0.2
  173  ls
  174  cd trec_eval-9.0.7
  175  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  176  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  177  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt

 
  185  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  186  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt


  191  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  192  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt

  195  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  196  nano /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel
 
  202  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  203  cp /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel.backup
  204  cp /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel.backup
  205  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  206  cat -A /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  207  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  208  cat -A /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  209  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  
  216  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt


  222  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  223  cd ..
  224  ls
  225  cat bm25_results.txt
  226  sudo su -
  227  sudo su -
  228  ls
  229  cd ..
  230  cd LuceneProject
  231  cd /home/azureuser/LuceneProject
  232  ls
  233  ls -l /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel
  234  ls -l /home/azureuser/LuceneProject/bm25_results.txt
  235  ls -l /home/azureuser/LuceneProject/vsm_results.txt

  239  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  240  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  241  cd trec_eval-9.0.7
  242  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  243  cd ..
  244  ls
  245  cd /home/azureuser/LuceneProject/trec_eval-9.0.7
  246  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  247  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  248  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  249  nano /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel
  
  254  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  
  257  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt

  264  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  265  nano /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel
  266  nano /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel
  273  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  274  ./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm25_results.txt
  277  ./trec_eval /home/azureuser/LuceneProject/cranfield_data/cran/cranqrel /home/azureuser/LuceneProject/vsm_results.txt
  278  sudo su -
  279  sudo su -
  280  ls
  281  cd LuceneProject
  282  ls
  283  history
  284  history > command_history.txt

#To copy file from vm to local
scp -i C:/Users/Vishaalini/Downloads/new_key_azure/ramasamv_key.pem azureuser@20.56.20.98:/home/azureuser/LuceneProject/command_history.txt C:/Users/Vishaalini/Downloads/

#vice versa
scp -i C:/Users/Vishaalini/Downloads/new_key_azure/ramasamv_key.pem C:/Users/Vishaalini/Downloads/search-engine-2-vishaalini_testParsing/search-engine-2-vishaalini_testParsing azureuser@20.56.20.98:/home/azureuser/LuceneProject2Test/

scp -i C:/Users/Vishaalini/Downloads/new_key_azure/ramasamv_key.pem -r C:/Users/Vishaalini/Downloads/search-engine-2-vishaalini_testParsing azureuser@20.56.20.98:/home/azureuser/LuceneProject2Test/


scp -i C:/Users/Vishaalini/Downloads/new_key_azure/ramasamv_key.pem C:/Users/Vishaalini/Downloads/english_vsm_results.txt azureuser@20.56.20.98:/home/azureuser/LuceneProject2Test/search-engine-2-vishaalini_testParsing/search-engine-2-vishaalini_testParsing/results


#To connect to VM
ssh azureuser@20.56.20.98 -i C:/Users/Vishaalini/Downloads/new_key_azure/ramasamv_key.pem


# Permission
sudo chmod -R 755 /home/azureuser/LuceneProject/target
sudo chown -R azureuser:azureuser /home/azureuser/LuceneProject/target


# run App_vsm.java
mvn exec:java -Dexec.mainClass="com.example.App_vsm" 


vsm -> import org.apache.lucene.search.similarities.ClassicSimilarity;
vsm -> indexSearcher.setSimilarity(new ClassicSimilarity());

#trec eval
./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/vsm_results1.txt
./trec_eval /home/azureuser/LuceneProject/cranfield_data1/cran/cranqrel /home/azureuser/LuceneProject/bm_results1.txt
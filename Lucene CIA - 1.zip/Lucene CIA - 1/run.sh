#!/bin/bash
# Step 1: Log into the VM
ssh azureuser@<vm_ip_address> -i <path_to_private_key>

# Step 2: Navigate to Project Directory
cd ~/path/to/your/project

# Step 3: Download Cranfield Collection
wget http://ir.dcs.gla.ac.uk/resources/test_collections/cran/cran.tar.gz
tar -xzf cran.tar.gz

# Step 4: Download and Install TREC_Eval
wget https://trec.nist.gov/trec_eval/trec_eval-9.0.7.tar.gz
tar -xzf trec_eval-9.0.7.tar.gz
cd trec_eval-9.0.7
make

# Step 5: Navigate Back to the Project Directory
cd ~/path/to/your/project

# Step 6: Compile Java Code
mvn compile

# Step 7: Index Documents
java -cp target/your_project.jar path.to.IndexerClass path/to/cran.all.1400
java -cp target/LuceneIndexer.jar com.example.lucene.DocIndexer


# Step 8: Query the Index
java -cp target/your_project.jar path.to.QueryProcessorClass path/to/cran.qry

# Step 9: Evaluate Results Using TREC_Eval
./trec_eval-9.0.7/trec_eval path/to/cran.qrel path/to/results_file

# Step 10: Display the Results (optional)
cat path/to/results_file
